
<!--
<link href="/jornada/css/noticia.css" rel="stylesheet" type="text/css">-->

<link rel="stylesheet" href="shadowbox/shadowbox.css" type="text/css" />

<div class="video">
       <!--<div class="mas-not"><h4>Videos </h4></div>-->
              <script type="text/javascript" src="http://c520866.r66.cf2.rackcdn.com/1/js/easy_rotator.min.js"></script>
                  <div class="dwuserEasyRotator" style="width: 311px; height: 220px; position:relative; text-align: left;" data-erconfig="{autoplayEnabled:false, autoplayDelay:6000, autoplayStopOnInteraction:false, lpp:'102-105-108-101-58-47-47-47-67-58-47-85-115-101-114-115-47-65-118-101-110-103-101-114-47-68-111-99-117-109-101-110-116-115-47-69-97-115-121-82-111-116-97-116-111-114-80-114-101-118-105-101-119-47-112-114-101-118-105-101-119-95-115-119-102-115-47'}" data-ername="videos">
                    <div data-ertype="content" style="display: none;"><ul data-erlabel="Main Category">
                         <li>
                             <a class="mainLink" href="http://www.youtube.com/embed/WgbOP311yek?hd=1&autoplay=1&rel=0" rel="shadowbox;width=720;height=480"><img class="main" src="youtube//img/videos/video2.jpg" /></a> <img class="thumb" src="/jornada/img/videos/video2.jpg" />
          </li>


                    <li>
                        <a class="mainLink" href="http://www.youtube.com/embed/8ULivxKG9A4?hd=1&autoplay=1&rel=0" rel="shadowbox;width=720;height=480"><img class="main" src="youtube/img/videos/video1.jpg" /></a> <img class="thumb" src="/jornada/img/videos/video1.jpg" />
  </li>
          

  
</ul>
</div>
                    <div data-ertype="layout" data-ertemplatename="NONE" style="">
                      <div class="erimgMain" style="position: position; left:0;right:0;top:0;bottom:0;" data-erconfig="{__numTiles:3, scaleMode:'showAvailable', imgType:'main', __loopNextButton:false, __arrowButtonMode:'rollover'}">
                        <div class="erimgMain_slides" style="position: absolute; left:0; top:0; bottom:0; right:0;">
                          <div class="erimgMain_slide">
                            <div class="erimgMain_img" style="position: absolute; left: 0; right: 0; top: 0; bottom: 0;"></div>
                          </div>
                        </div>
                        <div class="erimgMain_arrowLeft" style="position:absolute; left: 10px; top: 50%; margin-top: -15px;" data-erconfig="{image:'circleSmall', image2:'circleSmall'}"></div>
                        <div class="erimgMain_arrowRight" style="position:absolute; right: 10px; top: 50%; margin-top: -15px;" data-erconfig="{image:'circleSmall', image2:'circleSmall'}"></div>
                      </div>
                      <div class="erabout erFixCSS3" style="color: #FFF; text-align: left; background: #000; background:rgba(0,0,0,0.93); border: 2px solid #FFF; padding: 20px; font: normal 11px/14px Verdana,_sans; width: 300px; border-radius: 10px; display:none;"> This <a style="color:#FFF;" href="http://www.dwuser.com/easyrotator/" target="_blank">jQuery slider</a> was created with the free <a style="color:#FFF;" href="http://www.dwuser.com/easyrotator/" target="_blank">EasyRotator</a> software from DWUser.com. <br />
                        <br />
                        Need a powerful <a style="color:#FFF;" href="http://www.dwuser.com/flashslideshow/" target="_blank">Flash slideshow</a> creator with built-in iPhone/iPad/Android support?  EasyRotator is supported by the <a style="color:#FFF;" href="http://www.dwuser.com/flashslideshow/" target="_blank">XML Flash Slideshow v4 Software</a>. <br />
                        <br />
                      <a style="color:#FFF;" href="#" class="erabout_ok">OK</a> </div>
                      <noscript>
                      Rotator powered by <a href="http://www.dwuser.com/easyrotator/">EasyRotator</a>, a free and easy jQuery slider builder from DWUser.com.  Please enable JavaScript to view.
                      </noscript>
                      <script type="text/javascript">/*Avoid IE gzip bug*/(function(b,c,d){try{if(!b[d]){b[d]="temp";var a=c.createElement("script");a.type="text/javascript";a.src="http://easyrotator.s3.amazonaws.com/1/js/nozip/easy_rotator.min.js";c.getElementsByTagName("head")[0].appendChild(a)}}catch(e){alert("EasyRotator fail; contact support.")}})(window,document,"er_$144");</script>
                    </div>
                  </div>              </td>
       
         
 <script src="engine/js/visuallightbox.js" type="text/javascript"></script>
                 <link rel="stylesheet" type="text/css" href="youtube/shadowbox/shadowbox.css"/>
                <script type="text/javascript" src="youtube/shadowbox/shadowbox.js"></script>
                <script type="text/javascript">
                Shadowbox.init();
                </script> 

         </div><!--VIDEOS-->


