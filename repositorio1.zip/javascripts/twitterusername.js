jQuery(function($){
        $(".tweet").tweet({
            username: "twitter",
            avatar_size: 50,
            count: 1,
            loading_text: "loading tweets..."
        });
    });