<<<<<<< HEAD
hola juan, como esta ???
sabes la mina rica que te envie por fotos nunca la vi.. mina calieeennnnte compadre
=======asdfjasdhgfjhasgdjfgasjfgjasdghfjasdgfkjaghsdkfgaskdjgasdjf


holalalalalalallala soy juan
dkhskjhajkfhjdkahfjkshdfldsf
>>>>>>> 179c5dce8b22180fcdfe210139d7fbf9c83df389


JUAN GAY 